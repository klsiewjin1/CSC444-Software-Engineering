import googlemaps
import random

gmaps = googlemaps.Client(key='AIzaSyA7WO3rW4AqBy5OC6to9VSrV48OewIknbw')

class LatLonRangeInfo:
	def __init__(self, min_lat, max_lat, min_lon, max_lon, num_points):
		self.min_lat = min_lat
		self.max_lat = max_lat
		self.min_lon = min_lon
		self.max_lon = max_lon
		self.num_points = num_points

	def getRandomPointList(self):
		points = []
		converted_min_lat = int(self.min_lat * 1000000)
		converted_max_lat = int(self.max_lat * 1000000)
		converted_min_lon = int(self.min_lon * 1000000)
		converted_max_lon = int(self.max_lon * 1000000)

		for i in range(0, self.num_points):
			lat = random.randint(converted_min_lat, converted_max_lat) / 1000000
			lon = random.randint(converted_min_lon, converted_max_lon) / 1000000
			points.append((lat, lon))
		return points

def get_address(point):
	gmaps_results = gmaps.reverse_geocode(point)
	address = gmaps_results[0]['formatted_address'] + ', ' + str(point[0]) + ', ' + str(point[1])
	return address.replace(', ON ', ', ON, ')

address_file = open('addresses.txt', 'w')
# address_file = open('addresses2.txt', 'w')

infos = [LatLonRangeInfo(43.766156, 43.821668, -79.321112, -79.148077, 0)]
infos.append(LatLonRangeInfo(43.6684777, 43.879108, -79.601263, -79.241461, 0))
infos.append(LatLonRangeInfo(43.501769, 43.742349, -79.823736, -79.604010, 0))
infos.append(LatLonRangeInfo(43.581406, 43.625162, -79.636961, -79.496893, 0))
infos.append(LatLonRangeInfo(43.658081, 43.672486, -79.467711, -79.309096, 40))

i = 0

# to protect my account
# infos = []

for info in infos:
	points = info.getRandomPointList()
	for point in points:
		address = get_address(point)
		address_file.write(address + '\n')

		i += 1
		print(i)

address_file.close()