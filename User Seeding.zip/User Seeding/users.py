from random import *
from names import *

def writeCreateLine(file, user_type, fname, lname, cellphone, bdate, address, city, state, pcode, country, lat, lon, ending):
	fname_lower = fname.lower()
	lname_lower = lname.lower()

	user_type_text = 'user_type: \'' + user_type + '\''
	fname_text = 'fname: \'' + fname + '\''
	lname_text = 'lname: \'' + lname + '\''
	username_text = 'username: \'' + fname_lower + '_' + lname_lower + '\''
	email_text = 'email: \'' + fname_lower + '.' + lname_lower + '@gmail.com' + '\''
	cellphone_text = 'cellphone: \'' + cellphone + '\''
	bdate_text = 'bdate: ' + bdate
	address_text = 'address: \'' + address.replace('\'', "\'\\\'") + '\''
	city_text = 'city: \'' + city[1::] + '\''
	state_text = 'state: \'' + state[1::] + '\''
	pcode_text = 'pcode: \'' + pcode[1::] + '\''
	country_text = 'country: \'' + country[1::] + '\''
	lat_text = 'lat:' + lat
	lon_text = 'long:' + lon
	password_digest_text = 'password_digest: \'$2a$10$2pliEw8A2SGBsJPGrdLAcuqIkLRZ3AZclr/hUVEdHAT3EdR0dRHuK' + '\'' # password is 'password'

	file.write('{ ' + user_type_text + ', ' + fname_text + ', ' + lname_text + ', ' + username_text + ', ' + email_text + ', ' + 
					  cellphone_text + ', ' + bdate_text + ', ' + address_text + ', ' + city_text + ', ' + state_text + ', ' +
					  pcode_text + ', ' + country_text + ', ' + lat_text + ', ' + lon_text + ', ' + password_digest_text + ending)

address_file = open('addresses-Toronto.txt', 'r') # addresses.txt has 5000 addresses (also includes Mississauga and Scarborough)
user_file = open('users.txt', 'w')
user_file.write('# only delete users created through seeds.rb (password for seeded users is \'password\')\nUser.where(password_digest: \'$2a$10$2pliEw8A2SGBsJPGrdLAcuqIkLRZ3AZclr/hUVEdHAT3EdR0dRHuK\').delete_all\n\nusers = [\n')

num_users = 1000
for i in range(0, num_users):
	rand = randint(0, 1)
	birth_month = randint(1, 12)
	birth_day = randint(1, 28)
	if rand == 1:
		user_type = 'client'
		birth_year = randint(1950, 1996)
	else:
		user_type = 'teenager'
		birth_year = randint(1998, 2004)
	
	fname = FIRST_NAMES[i % 100] # index between 0 and 99
	lname = LAST_NAMES[int(i / 100)] # index between 0 and 49

	rand2 = randint(0, 1)
	if rand2 == 1:
		cellphone = str(randint(4160000000, 4169999999))
	else:
		cellphone = str(randint(6470000000, 6479999999))

	bdate = 'Date.new(' + str(birth_year) + ', ' + str(birth_month) + ', ' + str(birth_day) + ')'

	full_address = address_file.readline().split(',')

	if i == num_users - 1:
		ending = ' }\n]'
	else:
		ending = ' },\n'

	writeCreateLine(user_file, user_type, fname, lname, cellphone, bdate, full_address[0].replace('\'', '\\\''), full_address[1], full_address[2],
					full_address[3], full_address[4].replace('\'', '\\\''), full_address[5], full_address[6].replace('\n', ''), ending)